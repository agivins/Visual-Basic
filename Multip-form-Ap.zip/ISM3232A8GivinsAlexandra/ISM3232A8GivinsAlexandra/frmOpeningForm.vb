﻿Public Class frmTitle
	Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

	End Sub

	Private Sub btnQuit_MouseEnter(sender As Object, e As EventArgs) Handles btnQuit.MouseEnter
		btnQuit.BackColor = Color.Goldenrod
	End Sub


	Private Sub btnClickHeretoBegin_MouseEnter(sender As Object, e As EventArgs) Handles btnClickHeretoBegin.MouseEnter
		btnClickHeretoBegin.BackColor  = Color.Goldenrod
	End Sub

	Private Sub btnClickHeretoBegin_Click(sender As Object, e As EventArgs) Handles btnClickHeretoBegin.Click
		frmInstantiateAssetandDepreciation.Show()
	End Sub

	Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
		End
	End Sub
End Class
