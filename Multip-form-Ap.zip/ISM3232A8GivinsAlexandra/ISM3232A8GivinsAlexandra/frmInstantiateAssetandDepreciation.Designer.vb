﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInstantiateAssetandDepreciation
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.lblinfo = New System.Windows.Forms.Label()
		Me.lblAssetID = New System.Windows.Forms.Label()
		Me.txtAssetID = New System.Windows.Forms.TextBox()
		Me.lblAssetName = New System.Windows.Forms.Label()
		Me.txtAssetName = New System.Windows.Forms.TextBox()
		Me.lblOriginalvalue = New System.Windows.Forms.Label()
		Me.lblSalvageValue = New System.Windows.Forms.Label()
		Me.txtSalvageValue = New System.Windows.Forms.TextBox()
		Me.lblSalavageValue = New System.Windows.Forms.Label()
		Me.txtUsefulLife = New System.Windows.Forms.TextBox()
		Me.btnInstantiate = New System.Windows.Forms.Button()
		Me.txtOriginalValue = New System.Windows.Forms.TextBox()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.txtYear = New System.Windows.Forms.TextBox()
		Me.btnQueryStraightLineDepreciation = New System.Windows.Forms.Button()
		Me.lblDepreciationExpenseYear = New System.Windows.Forms.Label()
		Me.txtDepreciationExpenseYear = New System.Windows.Forms.TextBox()
		Me.lblAccumlatedDepreciation = New System.Windows.Forms.Label()
		Me.txtAccumlatedDepreciation = New System.Windows.Forms.TextBox()
		Me.lblBookValue = New System.Windows.Forms.Label()
		Me.txtBookValue = New System.Windows.Forms.TextBox()
		Me.btnQuit = New System.Windows.Forms.Button()
		Me.GroupBox1 = New System.Windows.Forms.GroupBox()
		Me.GroupBox2 = New System.Windows.Forms.GroupBox()
		Me.GroupBox1.SuspendLayout()
		Me.GroupBox2.SuspendLayout()
		Me.SuspendLayout()
		'
		'lblinfo
		'
		Me.lblinfo.AutoSize = True
		Me.lblinfo.Location = New System.Drawing.Point(256, 30)
		Me.lblinfo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.lblinfo.Name = "lblinfo"
		Me.lblinfo.Size = New System.Drawing.Size(385, 17)
		Me.lblinfo.TabIndex = 0
		Me.lblinfo.Text = "First instantiate an assest object then query its depreciation "
		'
		'lblAssetID
		'
		Me.lblAssetID.AutoSize = True
		Me.lblAssetID.ForeColor = System.Drawing.Color.Black
		Me.lblAssetID.Location = New System.Drawing.Point(41, 32)
		Me.lblAssetID.Name = "lblAssetID"
		Me.lblAssetID.Size = New System.Drawing.Size(60, 17)
		Me.lblAssetID.TabIndex = 2
		Me.lblAssetID.Text = "Asset ID"
		'
		'txtAssetID
		'
		Me.txtAssetID.Location = New System.Drawing.Point(151, 24)
		Me.txtAssetID.Name = "txtAssetID"
		Me.txtAssetID.Size = New System.Drawing.Size(100, 25)
		Me.txtAssetID.TabIndex = 3
		'
		'lblAssetName
		'
		Me.lblAssetName.AutoSize = True
		Me.lblAssetName.ForeColor = System.Drawing.Color.Black
		Me.lblAssetName.Location = New System.Drawing.Point(22, 82)
		Me.lblAssetName.Name = "lblAssetName"
		Me.lblAssetName.Size = New System.Drawing.Size(79, 17)
		Me.lblAssetName.TabIndex = 4
		Me.lblAssetName.Text = "Asset Name"
		'
		'txtAssetName
		'
		Me.txtAssetName.Location = New System.Drawing.Point(149, 74)
		Me.txtAssetName.Name = "txtAssetName"
		Me.txtAssetName.Size = New System.Drawing.Size(100, 25)
		Me.txtAssetName.TabIndex = 5
		'
		'lblOriginalvalue
		'
		Me.lblOriginalvalue.AutoSize = True
		Me.lblOriginalvalue.ForeColor = System.Drawing.Color.Black
		Me.lblOriginalvalue.Location = New System.Drawing.Point(22, 134)
		Me.lblOriginalvalue.Name = "lblOriginalvalue"
		Me.lblOriginalvalue.Size = New System.Drawing.Size(99, 17)
		Me.lblOriginalvalue.TabIndex = 6
		Me.lblOriginalvalue.Text = "Original Value"
		'
		'lblSalvageValue
		'
		Me.lblSalvageValue.AutoSize = True
		Me.lblSalvageValue.ForeColor = System.Drawing.Color.Black
		Me.lblSalvageValue.Location = New System.Drawing.Point(22, 163)
		Me.lblSalvageValue.Name = "lblSalvageValue"
		Me.lblSalvageValue.Size = New System.Drawing.Size(100, 17)
		Me.lblSalvageValue.TabIndex = 7
		Me.lblSalvageValue.Text = "Salvage Value "
		'
		'txtSalvageValue
		'
		Me.txtSalvageValue.Location = New System.Drawing.Point(149, 155)
		Me.txtSalvageValue.Name = "txtSalvageValue"
		Me.txtSalvageValue.Size = New System.Drawing.Size(100, 25)
		Me.txtSalvageValue.TabIndex = 8
		'
		'lblSalavageValue
		'
		Me.lblSalavageValue.AutoSize = True
		Me.lblSalavageValue.ForeColor = System.Drawing.Color.Black
		Me.lblSalavageValue.Location = New System.Drawing.Point(33, 190)
		Me.lblSalavageValue.Name = "lblSalavageValue"
		Me.lblSalavageValue.Size = New System.Drawing.Size(77, 17)
		Me.lblSalavageValue.TabIndex = 9
		Me.lblSalavageValue.Text = "Useful Life"
		'
		'txtUsefulLife
		'
		Me.txtUsefulLife.Location = New System.Drawing.Point(151, 190)
		Me.txtUsefulLife.Name = "txtUsefulLife"
		Me.txtUsefulLife.Size = New System.Drawing.Size(100, 25)
		Me.txtUsefulLife.TabIndex = 10
		'
		'btnInstantiate
		'
		Me.btnInstantiate.Location = New System.Drawing.Point(73, 251)
		Me.btnInstantiate.Name = "btnInstantiate"
		Me.btnInstantiate.Size = New System.Drawing.Size(164, 43)
		Me.btnInstantiate.TabIndex = 11
		Me.btnInstantiate.Text = "Instantiate "
		Me.btnInstantiate.UseVisualStyleBackColor = True
		'
		'txtOriginalValue
		'
		Me.txtOriginalValue.Location = New System.Drawing.Point(149, 124)
		Me.txtOriginalValue.Name = "txtOriginalValue"
		Me.txtOriginalValue.Size = New System.Drawing.Size(100, 25)
		Me.txtOriginalValue.TabIndex = 12
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.ForeColor = System.Drawing.Color.Goldenrod
		Me.Label1.Location = New System.Drawing.Point(23, 33)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(36, 17)
		Me.Label1.TabIndex = 14
		Me.Label1.Text = "Year"
		'
		'txtYear
		'
		Me.txtYear.Location = New System.Drawing.Point(63, 33)
		Me.txtYear.Name = "txtYear"
		Me.txtYear.Size = New System.Drawing.Size(100, 25)
		Me.txtYear.TabIndex = 15
		'
		'btnQueryStraightLineDepreciation
		'
		Me.btnQueryStraightLineDepreciation.Location = New System.Drawing.Point(278, 24)
		Me.btnQueryStraightLineDepreciation.Name = "btnQueryStraightLineDepreciation"
		Me.btnQueryStraightLineDepreciation.Size = New System.Drawing.Size(234, 36)
		Me.btnQueryStraightLineDepreciation.TabIndex = 16
		Me.btnQueryStraightLineDepreciation.Text = "Query Straight-Line Depreciation"
		Me.btnQueryStraightLineDepreciation.UseVisualStyleBackColor = True
		'
		'lblDepreciationExpenseYear
		'
		Me.lblDepreciationExpenseYear.AutoSize = True
		Me.lblDepreciationExpenseYear.ForeColor = System.Drawing.Color.Black
		Me.lblDepreciationExpenseYear.Location = New System.Drawing.Point(-3, 97)
		Me.lblDepreciationExpenseYear.Name = "lblDepreciationExpenseYear"
		Me.lblDepreciationExpenseYear.Size = New System.Drawing.Size(223, 17)
		Me.lblDepreciationExpenseYear.TabIndex = 17
		Me.lblDepreciationExpenseYear.Text = "Depreciation Expense for the year"
		'
		'txtDepreciationExpenseYear
		'
		Me.txtDepreciationExpenseYear.Location = New System.Drawing.Point(322, 89)
		Me.txtDepreciationExpenseYear.Name = "txtDepreciationExpenseYear"
		Me.txtDepreciationExpenseYear.Size = New System.Drawing.Size(157, 25)
		Me.txtDepreciationExpenseYear.TabIndex = 18
		'
		'lblAccumlatedDepreciation
		'
		Me.lblAccumlatedDepreciation.AutoSize = True
		Me.lblAccumlatedDepreciation.ForeColor = System.Drawing.Color.Black
		Me.lblAccumlatedDepreciation.Location = New System.Drawing.Point(46, 163)
		Me.lblAccumlatedDepreciation.Name = "lblAccumlatedDepreciation"
		Me.lblAccumlatedDepreciation.Size = New System.Drawing.Size(165, 17)
		Me.lblAccumlatedDepreciation.TabIndex = 19
		Me.lblAccumlatedDepreciation.Text = "Accumlated Depreciation"
		'
		'txtAccumlatedDepreciation
		'
		Me.txtAccumlatedDepreciation.Location = New System.Drawing.Point(322, 155)
		Me.txtAccumlatedDepreciation.Name = "txtAccumlatedDepreciation"
		Me.txtAccumlatedDepreciation.Size = New System.Drawing.Size(157, 25)
		Me.txtAccumlatedDepreciation.TabIndex = 20
		'
		'lblBookValue
		'
		Me.lblBookValue.AutoSize = True
		Me.lblBookValue.ForeColor = System.Drawing.Color.Black
		Me.lblBookValue.Location = New System.Drawing.Point(6, 221)
		Me.lblBookValue.Name = "lblBookValue"
		Me.lblBookValue.Size = New System.Drawing.Size(221, 17)
		Me.lblBookValue.TabIndex = 21
		Me.lblBookValue.Text = "Book Value at the end of the year "
		'
		'txtBookValue
		'
		Me.txtBookValue.Location = New System.Drawing.Point(322, 221)
		Me.txtBookValue.Name = "txtBookValue"
		Me.txtBookValue.Size = New System.Drawing.Size(157, 25)
		Me.txtBookValue.TabIndex = 22
		'
		'btnQuit
		'
		Me.btnQuit.Location = New System.Drawing.Point(389, 445)
		Me.btnQuit.Name = "btnQuit"
		Me.btnQuit.Size = New System.Drawing.Size(185, 44)
		Me.btnQuit.TabIndex = 23
		Me.btnQuit.Text = "Quit"
		Me.btnQuit.UseVisualStyleBackColor = True
		'
		'GroupBox1
		'
		Me.GroupBox1.Controls.Add(Me.txtAssetID)
		Me.GroupBox1.Controls.Add(Me.txtAssetName)
		Me.GroupBox1.Controls.Add(Me.txtOriginalValue)
		Me.GroupBox1.Controls.Add(Me.txtSalvageValue)
		Me.GroupBox1.Controls.Add(Me.txtUsefulLife)
		Me.GroupBox1.Controls.Add(Me.lblSalavageValue)
		Me.GroupBox1.Controls.Add(Me.lblSalvageValue)
		Me.GroupBox1.Controls.Add(Me.lblOriginalvalue)
		Me.GroupBox1.Controls.Add(Me.lblAssetName)
		Me.GroupBox1.Controls.Add(Me.lblAssetID)
		Me.GroupBox1.Controls.Add(Me.btnInstantiate)
		Me.GroupBox1.ForeColor = System.Drawing.Color.ForestGreen
		Me.GroupBox1.Location = New System.Drawing.Point(12, 101)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.Size = New System.Drawing.Size(305, 302)
		Me.GroupBox1.TabIndex = 24
		Me.GroupBox1.TabStop = False
		Me.GroupBox1.Text = "Instantiate"
		'
		'GroupBox2
		'
		Me.GroupBox2.Controls.Add(Me.Label1)
		Me.GroupBox2.Controls.Add(Me.txtYear)
		Me.GroupBox2.Controls.Add(Me.btnQueryStraightLineDepreciation)
		Me.GroupBox2.Controls.Add(Me.txtBookValue)
		Me.GroupBox2.Controls.Add(Me.lblDepreciationExpenseYear)
		Me.GroupBox2.Controls.Add(Me.txtAccumlatedDepreciation)
		Me.GroupBox2.Controls.Add(Me.lblBookValue)
		Me.GroupBox2.Controls.Add(Me.txtDepreciationExpenseYear)
		Me.GroupBox2.Controls.Add(Me.lblAccumlatedDepreciation)
		Me.GroupBox2.ForeColor = System.Drawing.Color.ForestGreen
		Me.GroupBox2.Location = New System.Drawing.Point(363, 95)
		Me.GroupBox2.Name = "GroupBox2"
		Me.GroupBox2.Size = New System.Drawing.Size(518, 332)
		Me.GroupBox2.TabIndex = 13
		Me.GroupBox2.TabStop = False
		Me.GroupBox2.Text = "Qurey"
		'
		'frmInstantiateAssetandDepreciation
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(1067, 588)
		Me.Controls.Add(Me.GroupBox2)
		Me.Controls.Add(Me.GroupBox1)
		Me.Controls.Add(Me.btnQuit)
		Me.Controls.Add(Me.lblinfo)
		Me.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.ForeColor = System.Drawing.Color.ForestGreen
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "frmInstantiateAssetandDepreciation"
		Me.Text = "Instantiate Asset Object & Depreciation"
		Me.GroupBox1.ResumeLayout(False)
		Me.GroupBox1.PerformLayout()
		Me.GroupBox2.ResumeLayout(False)
		Me.GroupBox2.PerformLayout()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents lblinfo As Label
	Friend WithEvents lblAssetID As Label
	Friend WithEvents txtAssetID As TextBox
	Friend WithEvents lblAssetName As Label
	Friend WithEvents txtAssetName As TextBox
	Friend WithEvents lblOriginalvalue As Label
	Friend WithEvents lblSalvageValue As Label
	Friend WithEvents txtSalvageValue As TextBox
	Friend WithEvents lblSalavageValue As Label
	Friend WithEvents txtUsefulLife As TextBox
	Friend WithEvents btnInstantiate As Button
	Friend WithEvents txtOriginalValue As TextBox
	Friend WithEvents Label1 As Label
	Friend WithEvents txtYear As TextBox
	Friend WithEvents btnQueryStraightLineDepreciation As Button
	Friend WithEvents lblDepreciationExpenseYear As Label
	Friend WithEvents txtDepreciationExpenseYear As TextBox
	Friend WithEvents lblAccumlatedDepreciation As Label
	Friend WithEvents txtAccumlatedDepreciation As TextBox
	Friend WithEvents lblBookValue As Label
	Friend WithEvents txtBookValue As TextBox
	Friend WithEvents btnQuit As Button
	Friend WithEvents GroupBox1 As GroupBox
	Friend WithEvents GroupBox2 As GroupBox
End Class
