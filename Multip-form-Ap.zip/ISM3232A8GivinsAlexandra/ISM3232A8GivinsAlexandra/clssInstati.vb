﻿Public Class clssInstantiate1
	Dim mAssetID As String
	Dim mAssetName As String
	Dim mOriginalValue As Single
	Dim mSalvageValue As Single
	Dim mUsefulLife As Short


	Property AssetID As String
		Get
			Return mAssetID
		End Get
		Set(ByVal value As String)
			mAssetID = value
		End Set
	End Property

	Property AssetName As String
		Get
			Return mAssetName
		End Get
		Set(ByVal value As String)
			mAssetName = value
		End Set
	End Property

	Property OriginalValue As Single
		Get
			Return mOriginalValue
		End Get
		Set(ByVal value As Single)
			mOriginalValue = value
		End Set
	End Property
	Property SalvageValue As Single
		Get
			Return mSalvageValue
		End Get
		Set(ByVal value As Single)
			mSalvageValue = value
		End Set
	End Property
	Property UsefulLife As Single
		Get
			Return mUsefulLife
		End Get
		Set(ByVal value As Single)
			mUsefulLife = value
		End Set
	End Property
	Sub QueryStraightLineDepreciation(ByVal Year As Integer, ByRef DepreciationExpenseYear As Single, ByRef AccumulatedDepreciation As Single, ByRef BookValue As Single)
		DepreciationExpenseYear = (OriginalValue - SalvageValue) / UsefulLife
		AccumulatedDepreciation = Year * DepreciationExpenseYear
		BookValue = OriginalValue - AccumulatedDepreciation
	End Sub

End Class

