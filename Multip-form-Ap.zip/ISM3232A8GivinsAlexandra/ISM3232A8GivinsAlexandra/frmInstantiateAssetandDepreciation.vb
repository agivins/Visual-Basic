﻿Public Class frmInstantiateAssetandDepreciation
	Dim AssetObject As New clssInstantiate1
	Private Sub lbl_Click(sender As Object, e As EventArgs) Handles lblAssetName.Click

	End Sub

	Private Sub txtUsefulLife_TextChanged(sender As Object, e As EventArgs) Handles txtUsefulLife.TextChanged

	End Sub

	Private Sub btnInstantiate_MouseEnter(sender As Object, e As EventArgs) Handles btnInstantiate.MouseEnter
		btnInstantiate.BackColor = Color.Goldenrod
	End Sub

	Private Sub btnQuit_MouseEnter(sender As Object, e As EventArgs) Handles btnQuit.MouseEnter
		btnQuit.BackColor = Color.Goldenrod

	End Sub

	Private Sub btnQueryStraightLineDepreciation_MouseEnter(sender As Object, e As EventArgs) Handles btnQueryStraightLineDepreciation.MouseEnter
		btnQueryStraightLineDepreciation.BackColor = Color.Goldenrod
	End Sub

	Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
		End
	End Sub

	Private Sub btnInstantiate_Click(sender As Object, e As EventArgs) Handles btnInstantiate.Click

		Try
			If txtAssetID.Text = "" Then Throw New ApplicationException(" Enter the Asset ID")
			If txtAssetName.Text = "" Then Throw New ApplicationException("Enter value for the Asset Name")
			If txtOriginalValue.Text = "" Then Throw New ApplicationException("Enter the Original Value")
			If txtSalvageValue.Text = "" Then Throw New ApplicationException(" Enter value for the Salvage Value")
			If txtUsefulLife.Text = "" Then Throw New ApplicationException(" Enter a value for the Useful Life ")


			If Not IsNumeric(txtOriginalValue.Text) Then Throw New ApplicationException("Enter a numeric value for the Original Value")
			If Not IsNumeric(txtSalvageValue.Text) Then Throw New ApplicationException(" Enter a numeric value for the Salvage Value")
			If Not IsNumeric(txtUsefulLife.Text) Then Throw New ApplicationException(" Enter a numeric value for the Useful Life of Asset")


			If (txtOriginalValue.Text) < 0 Then Throw New ApplicationException("Please enter a positive value for the Original Value")
			If (txtOriginalValue.Text) > 1000000 Then Throw New ApplicationException("Please enter a positive value for the Original Value")
			If (txtSalvageValue.Text) < 0 Then Throw New ApplicationException("Please enter a positive value for the Salvage Value")
			If (txtSalvageValue.Text) > 1000000 Then Throw New ApplicationException("Please enter a positive value for the Salvage Value")
			If (txtSalvageValue.Text) > txtOriginalValue.Text Then Throw New ApplicationException("The Salvage Value must be less than the Original Value ")
			If (txtUsefulLife.Text) < 0 Then Throw New ApplicationException("Please enter a positive value for the Useful Life")
			If (txtUsefulLife.Text) > 50 Then Throw New ApplicationException("The Useful Life cannot be more than 50 years")


			AssetObject.AssetID = txtAssetID.Text
			Assetobject.AssetName = txtAssetName.Text
			Assetobject.OriginalValue = txtOriginalValue.Text
			Assetobject.SalvageValue = txtSalvageValue.Text
			Assetobject.UsefulLife = txtUsefulLife.Text


			MsgBox(" The asset object has been instantiated. Perform the depreciation query")
		Catch ex As Exception
			MsgBox(ex.Message)
		End Try
	End Sub

	Private Sub frmInstantiateAssetandDepreciation_Load(sender As Object, e As EventArgs) Handles MyBase.Load

	End Sub

	Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

	End Sub

	Private Sub lblInstantiate_Click(sender As Object, e As EventArgs)

	End Sub

	Private Sub btnQueryStraightLineDepreciation_Click(sender As Object, e As EventArgs) Handles btnQueryStraightLineDepreciation.Click
		Try

			If AssetObject.OriginalValue = 0 Then Throw New ApplicationException("first instantiate an asset object")
			If txtYear.Text = "" Then Throw New ApplicationException("Please enter a Year value")
			If Not IsNumeric(txtYear.Text) Then Throw New ApplicationException("The Year value must be numeric")
			If txtYear.Text < 0 Then Throw New ApplicationException("The Year value must be positive")
			If Val(txtYear.Text) > AssetObject.UsefulLife Then Throw New ApplicationException("The Year value should be less than or equal to the useful life of the asset, which is " & AssetObject.UsefulLife)

			Dim Year As Integer = txtYear.Text



			Dim DepreciationExpenseYear As Single
			Dim AccumulatedDepreciation As Single
			Dim BookValue As Single



			Call AssetObject.QueryStraightLineDepreciation(Year, DepreciationExpenseYear, AccumulatedDepreciation, BookValue)
			txtDepreciationExpenseYear.Text = Format(DepreciationExpenseYear, "Currency")
			txtAccumlatedDepreciation.Text = Format(AccumulatedDepreciation, "Currency")
			txtBookValue.Text = Format(BookValue, "Currency")


		Catch ex As Exception
			MsgBox(ex.Message)
		End Try

	End Sub

	Private Sub lblDepreciationExpenseYear_Click(sender As Object, e As EventArgs) Handles lblDepreciationExpenseYear.Click

	End Sub
End Class