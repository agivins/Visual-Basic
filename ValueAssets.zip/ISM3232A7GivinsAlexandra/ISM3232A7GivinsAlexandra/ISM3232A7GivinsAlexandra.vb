﻿Public Class frmGivinsAlexandra
	Private Sub btnComputeDepreciationSchedule_Click(sender As Object, e As EventArgs) Handles btnComputeDepreciationSchedule.Click
		Try
			Dim OriginalVA As Single
			Dim SalvageVA As Single
			Dim UsefulLifeofA As Short


			If txtOriginalVA.Text = "" Then Throw New ApplicationException("Please enter value for the Original Value of Asset")
			If txtSalvageVA.Text = "" Then Throw New ApplicationException(" Please enter value for the Salvage Value of Asset")
			If txtUsefulLifeofA.Text = "" Then Throw New ApplicationException(" Please enter a value for the Useful Life of Asset")


			If Not IsNumeric(txtOriginalVA.Text) Then Throw New ApplicationException(" Please enter a numeric value for the Original Value of Asset")
			If Not IsNumeric(txtSalvageVA.Text) Then Throw New ApplicationException(" Please enter a numeric value for the Salvage Value of Asset")
			If Not IsNumeric(txtUsefulLifeofA.Text) Then Throw New ApplicationException(" Please enter a numeric value for the Useful Life of Asset")


			If txtOriginalVA.Text < 0 Then Throw New ApplicationException("Please enter a positive value for the Original Value of Asset")
			If txtSalvageVA.Text < 0 Then Throw New ApplicationException("Please enter a positive value for the Salvage Value of Asset")
			If txtUsefulLifeofA.Text < 0 Then Throw New ApplicationException("Please enter a positive value for the Useful Life of Asset")

			If txtOriginalVA.Text > txtSalvageVA.Text Then Throw New ApplicationException("Please enter a value that is less then your Original Value of Asset")



			OriginalVA = txtOriginalVA.Text
			SalvageVA = txtSalvageVA.Text

			OriginalVA = txtOriginalVA.Text
			SalvageVA = txtSalvageVA.Text
			UsefulLifeofA = txtUsefulLifeofA.Text

			Call ComputeDepreciationSchedule(OriginalVA, SalvageVA, UsefulLifeofA)
		Catch ex As Exception
			MsgBox(ex.Message)
		End Try
	End Sub


	Sub ComputeDepreciationSchedule(ByVal OriginalVA As Single, ByVal SalvageVA As Single, ByVal UsefulLifeofA As Short)
		Try
			Dim Counter As Short
			Dim RowCounter As Short
			Dim DepreciationsExpense As Single
			Dim BookValue As Single
			Dim AccumulatedDepreciation As Single
			BookValue = OriginalVA
			'DepreciationsExpense = Financial.SLN(OriginalVA, SalvageVA, UsefulLifeofA)


			lvwComputeDepreciationSchedule.Items.Clear()
			For Counter = 1 To UsefulLifeofA
				DepreciationsExpense = (OriginalVA - SalvageVA) / UsefulLifeofA
				AccumulatedDepreciation = AccumulatedDepreciation + DepreciationsExpense
				BookValue = OriginalVA - AccumulatedDepreciation

				lvwComputeDepreciationSchedule.Items.Add(Counter)
				lvwComputeDepreciationSchedule.Items(RowCounter).SubItems.Add(Format(DepreciationsExpense, "currency"))
				lvwComputeDepreciationSchedule.Items(RowCounter).SubItems.Add(Format(AccumulatedDepreciation, "currency"))
				lvwComputeDepreciationSchedule.Items(RowCounter).SubItems.Add(Format(BookValue, "currency"))
				RowCounter += 1
			Next

		Catch ex As Exception
			MsgBox(ex.Message)
		End Try
	End Sub

End Class
