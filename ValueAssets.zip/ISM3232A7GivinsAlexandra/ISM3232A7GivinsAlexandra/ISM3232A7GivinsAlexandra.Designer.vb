﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGivinsAlexandra
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.lblDepreciationScheduleCalculator = New System.Windows.Forms.Label()
		Me.lblName = New System.Windows.Forms.Label()
		Me.lblOriginalVA = New System.Windows.Forms.Label()
		Me.lblSalvageVA = New System.Windows.Forms.Label()
		Me.lblUsefulLA = New System.Windows.Forms.Label()
		Me.txtOriginalVA = New System.Windows.Forms.TextBox()
		Me.txtSalvageVA = New System.Windows.Forms.TextBox()
		Me.txtUsefulLifeofA = New System.Windows.Forms.TextBox()
		Me.btnComputeDepreciationSchedule = New System.Windows.Forms.Button()
		Me.lvwComputeDepreciationSchedule = New System.Windows.Forms.ListView()
		Me.chdYear = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
		Me.chdDepreciationExpense = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
		Me.chdAccumulatedDepreciation = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
		Me.chdBookValue = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
		Me.SuspendLayout()
		'
		'lblDepreciationScheduleCalculator
		'
		Me.lblDepreciationScheduleCalculator.AutoSize = True
		Me.lblDepreciationScheduleCalculator.Font = New System.Drawing.Font("Times New Roman", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblDepreciationScheduleCalculator.Location = New System.Drawing.Point(214, -1)
		Me.lblDepreciationScheduleCalculator.Name = "lblDepreciationScheduleCalculator"
		Me.lblDepreciationScheduleCalculator.Size = New System.Drawing.Size(401, 31)
		Me.lblDepreciationScheduleCalculator.TabIndex = 0
		Me.lblDepreciationScheduleCalculator.Text = "Depreciation Schedule Calculator"
		'
		'lblName
		'
		Me.lblName.AutoSize = True
		Me.lblName.Font = New System.Drawing.Font("Monotype Corsiva", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblName.Location = New System.Drawing.Point(331, 43)
		Me.lblName.Name = "lblName"
		Me.lblName.Size = New System.Drawing.Size(154, 22)
		Me.lblName.TabIndex = 1
		Me.lblName.Text = "By Alexandra Givins"
		'
		'lblOriginalVA
		'
		Me.lblOriginalVA.AutoSize = True
		Me.lblOriginalVA.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblOriginalVA.Location = New System.Drawing.Point(217, 100)
		Me.lblOriginalVA.Name = "lblOriginalVA"
		Me.lblOriginalVA.Size = New System.Drawing.Size(132, 15)
		Me.lblOriginalVA.TabIndex = 2
		Me.lblOriginalVA.Text = "Original Value of Asset"
		'
		'lblSalvageVA
		'
		Me.lblSalvageVA.AutoSize = True
		Me.lblSalvageVA.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblSalvageVA.Location = New System.Drawing.Point(217, 141)
		Me.lblSalvageVA.Name = "lblSalvageVA"
		Me.lblSalvageVA.Size = New System.Drawing.Size(129, 15)
		Me.lblSalvageVA.TabIndex = 3
		Me.lblSalvageVA.Text = "Salvage Value of Asset"
		'
		'lblUsefulLA
		'
		Me.lblUsefulLA.AutoSize = True
		Me.lblUsefulLA.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblUsefulLA.Location = New System.Drawing.Point(217, 191)
		Me.lblUsefulLA.Name = "lblUsefulLA"
		Me.lblUsefulLA.Size = New System.Drawing.Size(108, 15)
		Me.lblUsefulLA.TabIndex = 4
		Me.lblUsefulLA.Text = "Useful Life of Asset"
		'
		'txtOriginalVA
		'
		Me.txtOriginalVA.Location = New System.Drawing.Point(477, 95)
		Me.txtOriginalVA.Name = "txtOriginalVA"
		Me.txtOriginalVA.Size = New System.Drawing.Size(100, 20)
		Me.txtOriginalVA.TabIndex = 5
		'
		'txtSalvageVA
		'
		Me.txtSalvageVA.Location = New System.Drawing.Point(477, 136)
		Me.txtSalvageVA.Name = "txtSalvageVA"
		Me.txtSalvageVA.Size = New System.Drawing.Size(100, 20)
		Me.txtSalvageVA.TabIndex = 6
		'
		'txtUsefulLifeofA
		'
		Me.txtUsefulLifeofA.Location = New System.Drawing.Point(477, 186)
		Me.txtUsefulLifeofA.Name = "txtUsefulLifeofA"
		Me.txtUsefulLifeofA.Size = New System.Drawing.Size(100, 20)
		Me.txtUsefulLifeofA.TabIndex = 7
		'
		'btnComputeDepreciationSchedule
		'
		Me.btnComputeDepreciationSchedule.Font = New System.Drawing.Font("Times New Roman", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btnComputeDepreciationSchedule.Location = New System.Drawing.Point(220, 235)
		Me.btnComputeDepreciationSchedule.Name = "btnComputeDepreciationSchedule"
		Me.btnComputeDepreciationSchedule.Size = New System.Drawing.Size(357, 40)
		Me.btnComputeDepreciationSchedule.TabIndex = 8
		Me.btnComputeDepreciationSchedule.Text = "Compute Depreciation Schedule"
		Me.btnComputeDepreciationSchedule.UseVisualStyleBackColor = True
		'
		'lvwComputeDepreciationSchedule
		'
		Me.lvwComputeDepreciationSchedule.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chdYear, Me.chdDepreciationExpense, Me.chdAccumulatedDepreciation, Me.chdBookValue})
		Me.lvwComputeDepreciationSchedule.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lvwComputeDepreciationSchedule.Location = New System.Drawing.Point(12, 293)
		Me.lvwComputeDepreciationSchedule.Name = "lvwComputeDepreciationSchedule"
		Me.lvwComputeDepreciationSchedule.Size = New System.Drawing.Size(776, 142)
		Me.lvwComputeDepreciationSchedule.TabIndex = 9
		Me.lvwComputeDepreciationSchedule.UseCompatibleStateImageBehavior = False
		Me.lvwComputeDepreciationSchedule.View = System.Windows.Forms.View.Details
		'
		'chdYear
		'
		Me.chdYear.Text = "Year"
		Me.chdYear.Width = 109
		'
		'chdDepreciationExpense
		'
		Me.chdDepreciationExpense.Text = "Depreciation Expense "
		Me.chdDepreciationExpense.Width = 166
		'
		'chdAccumulatedDepreciation
		'
		Me.chdAccumulatedDepreciation.Text = "Accumulated Depreciation"
		Me.chdAccumulatedDepreciation.Width = 185
		'
		'chdBookValue
		'
		Me.chdBookValue.Text = "Book Value at end of Year "
		Me.chdBookValue.Width = 179
		'
		'frmGivinsAlexandra
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(800, 450)
		Me.Controls.Add(Me.lvwComputeDepreciationSchedule)
		Me.Controls.Add(Me.btnComputeDepreciationSchedule)
		Me.Controls.Add(Me.txtUsefulLifeofA)
		Me.Controls.Add(Me.txtSalvageVA)
		Me.Controls.Add(Me.txtOriginalVA)
		Me.Controls.Add(Me.lblUsefulLA)
		Me.Controls.Add(Me.lblSalvageVA)
		Me.Controls.Add(Me.lblOriginalVA)
		Me.Controls.Add(Me.lblName)
		Me.Controls.Add(Me.lblDepreciationScheduleCalculator)
		Me.Name = "frmGivinsAlexandra"
		Me.Text = "ISM 3232, Assignment 7 by Alexandra Givins"
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents lblDepreciationScheduleCalculator As Label
	Friend WithEvents lblName As Label
	Friend WithEvents lblOriginalVA As Label
	Friend WithEvents lblSalvageVA As Label
	Friend WithEvents lblUsefulLA As Label
	Friend WithEvents txtOriginalVA As TextBox
	Friend WithEvents txtSalvageVA As TextBox
	Friend WithEvents txtUsefulLifeofA As TextBox
	Friend WithEvents btnComputeDepreciationSchedule As Button
	Friend WithEvents lvwComputeDepreciationSchedule As ListView
	Friend WithEvents chdYear As ColumnHeader
	Friend WithEvents chdDepreciationExpense As ColumnHeader
	Friend WithEvents chdAccumulatedDepreciation As ColumnHeader
	Friend WithEvents chdBookValue As ColumnHeader
End Class
