﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmISM3232A2GivinsAlexandra
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn1DisplayAge = New System.Windows.Forms.Button()
        Me.lbl1Title = New System.Windows.Forms.Label()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.lblYearofBirth = New System.Windows.Forms.Label()
        Me.lblNoteFirstName = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.txtYearofBirth = New System.Windows.Forms.TextBox()
        Me.lblSales = New System.Windows.Forms.Label()
        Me.lblNoteSalesTax = New System.Windows.Forms.Label()
        Me.txtSales = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnSalesTaxes = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn1DisplayAge
        '
        Me.btn1DisplayAge.Location = New System.Drawing.Point(367, 223)
        Me.btn1DisplayAge.Name = "btn1DisplayAge"
        Me.btn1DisplayAge.Size = New System.Drawing.Size(165, 47)
        Me.btn1DisplayAge.TabIndex = 0
        Me.btn1DisplayAge.Text = "Display Age "
        Me.btn1DisplayAge.UseVisualStyleBackColor = True
        '
        'lbl1Title
        '
        Me.lbl1Title.AutoSize = True
        Me.lbl1Title.Font = New System.Drawing.Font("Times New Roman", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1Title.Location = New System.Drawing.Point(270, 9)
        Me.lbl1Title.Name = "lbl1Title"
        Me.lbl1Title.Size = New System.Drawing.Size(311, 24)
        Me.lbl1Title.TabIndex = 1
        Me.lbl1Title.Text = "Assignment 2 by Alexandra Givins"
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFirstName.Location = New System.Drawing.Point(253, 117)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(67, 15)
        Me.lblFirstName.TabIndex = 2
        Me.lblFirstName.Text = "First Name:"
        '
        'lblYearofBirth
        '
        Me.lblYearofBirth.AutoSize = True
        Me.lblYearofBirth.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYearofBirth.Location = New System.Drawing.Point(253, 167)
        Me.lblYearofBirth.Name = "lblYearofBirth"
        Me.lblYearofBirth.Size = New System.Drawing.Size(119, 15)
        Me.lblYearofBirth.TabIndex = 3
        Me.lblYearofBirth.Text = "Year of Birth (YYYY):"
        '
        'lblNoteFirstName
        '
        Me.lblNoteFirstName.AutoSize = True
        Me.lblNoteFirstName.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNoteFirstName.Location = New System.Drawing.Point(143, 69)
        Me.lblNoteFirstName.Name = "lblNoteFirstName"
        Me.lblNoteFirstName.Size = New System.Drawing.Size(539, 19)
        Me.lblNoteFirstName.TabIndex = 4
        Me.lblNoteFirstName.Text = "Please enter your first name and the year of birth and click the Display Age butt" &
    "on"
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(481, 112)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(100, 20)
        Me.txtFirstName.TabIndex = 5
        '
        'txtYearofBirth
        '
        Me.txtYearofBirth.Location = New System.Drawing.Point(481, 165)
        Me.txtYearofBirth.Name = "txtYearofBirth"
        Me.txtYearofBirth.Size = New System.Drawing.Size(100, 20)
        Me.txtYearofBirth.TabIndex = 6
        '
        'lblSales
        '
        Me.lblSales.AutoSize = True
        Me.lblSales.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSales.Location = New System.Drawing.Point(334, 352)
        Me.lblSales.Name = "lblSales"
        Me.lblSales.Size = New System.Drawing.Size(38, 15)
        Me.lblSales.TabIndex = 7
        Me.lblSales.Text = "Sales:"
        '
        'lblNoteSalesTax
        '
        Me.lblNoteSalesTax.AutoSize = True
        Me.lblNoteSalesTax.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNoteSalesTax.Location = New System.Drawing.Point(227, 304)
        Me.lblNoteSalesTax.Name = "lblNoteSalesTax"
        Me.lblNoteSalesTax.Size = New System.Drawing.Size(455, 19)
        Me.lblNoteSalesTax.TabIndex = 8
        Me.lblNoteSalesTax.Text = "Please enter the Sales amount and click the Display Sales Tax button "
        '
        'txtSales
        '
        Me.txtSales.Location = New System.Drawing.Point(481, 347)
        Me.txtSales.Name = "txtSales"
        Me.txtSales.Size = New System.Drawing.Size(100, 20)
        Me.txtSales.TabIndex = 9
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(0, 0)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnSalesTaxes
        '
        Me.btnSalesTaxes.Location = New System.Drawing.Point(367, 392)
        Me.btnSalesTaxes.Name = "btnSalesTaxes"
        Me.btnSalesTaxes.Size = New System.Drawing.Size(165, 46)
        Me.btnSalesTaxes.TabIndex = 11
        Me.btnSalesTaxes.Text = "Display Sales Tax"
        Me.btnSalesTaxes.UseVisualStyleBackColor = True
        '
        'frmISM3232A2GivinsAlexandra
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnSalesTaxes)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtSales)
        Me.Controls.Add(Me.lblNoteSalesTax)
        Me.Controls.Add(Me.lblSales)
        Me.Controls.Add(Me.txtYearofBirth)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.lblNoteFirstName)
        Me.Controls.Add(Me.lblYearofBirth)
        Me.Controls.Add(Me.lblFirstName)
        Me.Controls.Add(Me.lbl1Title)
        Me.Controls.Add(Me.btn1DisplayAge)
        Me.Name = "frmISM3232A2GivinsAlexandra"
        Me.Text = "ISM3232 Assignment 2 by Alexandra Givins "
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn1DisplayAge As Button
    Friend WithEvents lbl1Title As Label
    Friend WithEvents lblFirstName As Label
    Friend WithEvents lblYearofBirth As Label
    Friend WithEvents lblNoteFirstName As Label
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents txtYearofBirth As TextBox
    Friend WithEvents lblSales As Label
    Friend WithEvents lblNoteSalesTax As Label
    Friend WithEvents txtSales As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents btnSalesTaxes As Button
End Class
