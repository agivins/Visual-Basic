﻿Public Class frmISM3232A2GivinsAlexandra

    Private Sub btn1DisplayAge_Click(sender As Object, e As EventArgs) Handles btn1DisplayAge.Click
        Dim FirstName As String = txtFirstName.Text
        Dim Age As String
        Const Year As Short = 2019
        Dim BYear As Short = txtYearofBirth.Text
        Age = Year - BYear

        MsgBox(" Dear " & FirstName & ",you are approximately " & Age & " years old.")

    End Sub

    Private Sub btnSalesTaxes_Click(sender As Object, e As EventArgs) Handles btnSalesTaxes.Click
        Dim SalesTax As Single
        Const TaxRate As Decimal = 0.07
        Dim Sales As String = txtSales.Text
        SalesTax = Sales * TaxRate
        MsgBox(" Your sales tax amount is: " & SalesTax)
    End Sub
End Class
